<div class="col-md-4 item-pearl">
	<div class="content-pearl">
		<h3 class="title-pearl"><a href="<?php echo the_permalink(get_the_ID()); ?>"><?php the_title(); ?></a></h3>
		<hr>
		<div class="text-right d-block d-sm-block d-md-none">
			<a href="<?php echo the_permalink(get_the_ID()); ?>"" class="btn btn-primary btn-sm">
				<?php _e('Veja mais', 'bvs_lang'); ?> <span class="fas fa-arrow-right"></span>
			</a>
		</div>
	</div>
</div>