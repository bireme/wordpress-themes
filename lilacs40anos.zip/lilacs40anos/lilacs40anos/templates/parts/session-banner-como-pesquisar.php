
$post_id      = get_the_ID();
$banner_title = get_post_meta($post_id, '_lilacs_cp_banner_title', true);
$banner_desc  = get_post_meta($post_id, '_lilacs_cp_banner_desc', true);
$banner_imgid = (int) get_post_meta($post_id, '_lilacs_cp_banner_img_id', true);
$banner_img   = $banner_imgid ? wp_get_attachment_image_url($banner_imgid, 'full') : '';

if (!$banner_title) $banner_title = get_the_title($post_id);
?>
<section id="lilacs-cp-banner" aria-label="Como pesquisar na LILACS – Banner"
  <?php if ($banner_img): ?> style="--cp-bg:url('<?php echo esc_url($banner_img); ?>');"<?php endif; ?>>
  <style>
    #lilacs-cp-banner{
      position:relative;
      padding:0;
      background:#f3f4f6;
      overflow:hidden;
      /* usa CSS var como background quando houver imagem */
      --cp-bg:none;
    }
    #lilacs-cp-banner .cp-hero{
         position: relative;
    padding: 44px 0 36px;
    background: #f3f4f6;
    min-height: 350px;
    display: flex
;
    align-items: center;
    }
    /* plano de fundo do banner (imagem) */
    #lilacs-cp-banner .cp-hero::before{
      content:"";
      position:absolute; inset:0;
      background-image: var(--cp-bg);
      background-size: cover;
      background-position: center right;
      background-repeat:no-repeat;
      opacity:1;
      z-index:0;
      transform:translateZ(0);
    }
    /* degradê para leitura (claro -> transparente) */
    #lilacs-cp-banner .cp-hero::after{
      content:"";
      position:absolute; inset:0;
      background: linear-gradient(90deg, rgba(243,244,246,.95) 0%,
                                         rgba(243,244,246,.80) 28%,
                                         rgba(243,244,246,.35) 58%,
                                         rgba(243,244,246,0) 100%);
      z-index:1;
      pointer-events:none;
    }

    #lilacs-cp-banner .cp-wrap{
    position: relative;
    z-index: 2;
    max-width: 100%;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    flex-direction: column;
    align-content: flex-start;
    align-items: flex-start;
    justify-content: center;
    width: 64%;
    }

    #lilacs-cp-banner .cp-title{
        color: #F96A1E;
    letter-spacing: .2px;
    margin: 0 0 8px;
    text-transform: uppercase;
    text-wrap: balance;
    font-family: 'Noto Sans';
    font-size: 48px !important;
    font-weight: 700;
    }
    #lilacs-cp-banner .cp-desc{
    color: #00205C;
    max-width: 880px;
    margin: 0;
    letter-spacing: .2px;
    font-family: 'Noto Sans';
    font-size: 24px !important;
    font-weight: 500;
    }

    @media(min-width:992px){
      #lilacs-cp-banner .cp-hero{ padding:60px 0 48px; }
      #lilacs-cp-banner .cp-title{ font-size:44px; }
      #lilacs-cp-banner .cp-desc{ font-size:19px; }
    }
  </style>

  <div class="cp-hero">
    <div class="cp-wrap">
      <h1 class="cp-title"><?php echo esc_html($banner_title); ?></h1>
      <?php if (!empty($banner_desc)) : ?>
        <p class="cp-desc"><?php echo wp_kses_post($banner_desc); ?></p>
      <?php endif; ?>
    </div>
  </div>
</section>

<main id="primary" class="site-main">
  <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
</main>